<?php
    $times = 
        [
            ["Days" => "Monday", "Opening Times" => "8am", "Closing Times" => "9pm"],
            ["Days" => "Tuesday", "Opening Times" => "8am", "Closing Times" => "9pm"],
            ["Days" => "Wednesday", "Opening Times" => "9am", "Closing Times" => "9pm"],
            ["Days" => "Thursday", "Opening Times" => "8am", "Closing Times" => "8pm"],
            ["Days" => "Friday", "Opening Times" => "9am", "Closing Times" => "9pm"],
            ["Days" => "Saturday", "Opening Times" => "10am", "Closing Times" => "5pm"],
            ["Days" => "Sunday", "Opening Times" => "11am", "Closing Times" => "4pm"]
        ];
?>
 table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
        
    }
    th, td {
        padding: 5px;
        margin: 90px;
    }
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="keywords" content="Paradise Lagoon, Resort, Paradise, WaterSports">
        <meta name="description" content="Paradise Lagoon Resort is located in the heart of South East Queensland!">
        <title>Facilities</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>

        <body>
            <div id="global">
            <div id="banner"></div>
            <div id="navbar">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
                            <li><a href="about us.php">About Us</a></li>
                            <li><a href="contact us.php">Contact Us</a></li>
                        </ul>
            </div>
            <div id="content">
                <div id="leftColumn">
                    
                        <h1>Standard Rooms</h1>
                        
                            <p>Wide and luscious ocean views, large terrace/balcony, floor-to-ceiling windows, king-size bed or twin beds, LCD TV.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                            tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at.</p>
                            <p>Relax and indulge in the bathroom with separate shower and bathtub.Other amenities include Free Wi-Fi, DVD player, and alarm clock radio.</p>
                            
                        <img src="img/Standard-Room.jpg" width="545" height="408" alt="Standard Room">  
                        
                        <h1>Superior Rooms</h1>
                            <p>Large spacious rooms capiable with holding up to 4 adults.</p>
                            <p>Stay here now in ths studio suite with tranquil surroundings, amoung lush garden views and with a private balcony. Now available with a king-size bed or twin beds, this suite includes a separate living 
                            area and bathroom with separate shower and tub.</p>
                        
                        <img src="img/Superior-Bedroom.jpg" width="545" height="408" alt="Superior Bedroom">
                        
                        <h1>Relax with a movie on the flat screen TV with DVD player. Free Wi-Fi</h1> 
                        
                            <p>Do check out our amazing rooms, equipped with the state of the art bathrooms and accessories. Our rooms are top quality offering lovely Beach side balconies and views which 
                            will entrance all Tourist who stay at our resort.</p>  
                        
                        <img src="img/Apartment-Bathroom.jpg" width="545" height="408" alt="Apartment bathroom">
                    
                    <div class="sociallinks">
                        <a href="https://www.facebook.com"> 
                            <img src="img/media_fb.png" alt="FaceBook"/></a>
                        <a href="https://twitter.com">
                            <img src="img/media_twitter.png" alt="Twitter"/></a> 
                    </div>
                    
                </div>
                
                <div id="rightColumn">
                    
                    <h1>Apartments</h1>
                    
                        <p>Free Wi-F, LCD TV with DVD player, ocean view, separate kitchen and living room, terrace/balcony.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien 
                        molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in tincidunt erat nunc vitae leo. 
                        Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel 
                        bibendum nisi pharetra at.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. 
                        Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in tincidunt erat nunc vitae leo. Ut at pharetra ipsum. 
                        Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at. </p>
                            
                    
                    <img src="img/Apartment-Bedroom.jpg" width="545" height="408" alt="Apartment-Bathroom"/>
                    
                    <h1>Fully Equipped Gym</h1>
                            
                            <p>Work off those extra holiday pounds with a session in our modern, fully equipped.</p>
                    
                    <img src="img/Fully-equiped-gym.jpg" width="545" height="410" alt="Equiped gym"/>
                    
                    <h1>Gym Times</h1> 
                        <table>
                            <thead>
                                <tr>
                                    <th>Days</th>
                                    <th>Opening Times</th>
                                    <th>Closing Times</th>
                                </tr>
                            </thead>
                                 <?php
                                        foreach ($times as $time)
                                    {
                                         echo "<tr>";
                                            echo "<td>" . $time["Days"] . "</td>";
                                            echo "<td>" . $time["Opening Times"] . "</td>";
                                            echo "<td>" . $time["Closing Times"] . "</td>";
                                         echo "</tr>";
                                         }
                                 ?>
                        </table> 
                          
                </div>
                    <hr>
                <div id="footer">
                        <p>Griffith University</p>
                        <p>(07) 3735 7111 Griffith University</p>
                        <p>Terms & Conditions</p>
                        <p>Privacy Statement </p>
                        <p>F.A.Q.s</p>
                        <p>Support</p>
                        <p>© Copyright 2016 Paradise Lagoon Resort</p>
                </div>
            </div> 
        </div>
        </body>
</html>
