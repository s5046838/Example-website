<?php
require_once "queryDb.php";
$search = $_GET["title"];
$times = getCustomers($search);
        
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="keywords" content="Paradise Lagoon, Resort, Paradise, WaterSports">
        <meta name="description" content="Paradise Lagoon Resort is located in the heart of South East Queensland!"> 
        <title>Contact Us</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>
        <body>
            <div id="global">
            <div id="banner"></div>
            <div id="navbar">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                        <li><a href="about us.php">About Us</a></li>
                        <li><a href="contact us.php">Contact Us</a></li>
                    </ul>
            </div>
                <div id="widercontent">
                    <div id="leftColumn">
                        
                        <Span><h1>Contact Us!</h1></Span>
                        
                            <table>
                                <tr><td>Name</td></tr>
                                <tr><td>E-mail Address</td></tr>
                                <tr><td>Phone Number</td></tr>
                                <tr><td>Subject</td></tr>
                                <tr id="contactform"><td>Message</td></tr>
                            </table>
                    </div>
                    
                    <div id="rightColumn">
                        
                            <span><h1>Our Location!</h1></span>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3524.0025973827824!2d153.3822496189416!3d-27.
                                963206696694314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b911004949ab5b1%3A0x605fe6e437c1102d!2sGriffith+University!
                                5e0!3m2!1sen!2sau!4v1462606054566"
                                frameborder="0" 
                                style="border:0">
                                </iframe>
                    </div>
                            <p class="textspacing">Need more help?   Search and contact one of our trusted employees!</p>
                    <div class="searchbar">
                        
                             <form class="form-inline" action="contact us.php" method="get">
                                <fieldset>
                                    <label><span>Find!</span></label>
                                        <input class="search" type="text" id="title" name="title" />
                                        <input type="submit" value="Search" class ="button" />
                                </fieldset>
                            </form>
                    </div>
                    <div class="data">
                        
                            <table class="database">
                                <thead>
                                    <tr>
                                        <th>Firstname</th>
                                        <th>Lastname</th>
                                        <th>Address</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                    <?php
                                        foreach ($times as $time)
                                            {
                                            echo "<tr>";
                                                echo "<td>" . $time["FIRSTNAME"] . "</td>";
                                                echo "<td>" . $time["LASTNAME"] . "</td>";
                                                echo "<td>" . $time["ADDRESS"] . "</td>";
                                                echo "<td>" . $time["PHONE"] . "</td>";
                                            echo "</tr>";
                                            }
                                    ?>
                            </table> 
                    </div>
                   <div id="sociallinks">
                        <a href="https://www.facebook.com"> 
                            <img src="img/media_fb.png" alt="FaceBook"/></a>
                        <a href="https://twitter.com">
                            <img src="img/media_twitter.png" alt="Twitter"/></a> 
                   </div>
                        <hr>
                    <div id="footer">
                            <p>Griffith University</p>
                            <p>(07) 3735 7111 Griffith University</p>
                            <p>Terms & Conditions</p>
                            <p>Privacy Statement </p>
                            <p>F.A.Q.s</p>
                            <p>Support</p>
                            <p>© Copyright 2016 Paradise Lagoon Resort</p>
                    </div>
                </div>
            </div>
        </body>
</html>
