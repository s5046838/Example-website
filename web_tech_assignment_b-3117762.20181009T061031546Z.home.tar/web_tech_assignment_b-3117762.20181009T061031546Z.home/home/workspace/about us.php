
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="keywords" content="Paradise Lagoon, Resort, Paradise, WaterSports">
        <meta name="description" content="Paradise Lagoon Resort is located in the heart of South East Queensland!">
        <title>About Us</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>

    <body>
        <div id="global">
        <div id="banner"></div>
        <div id="navbar">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="facilities.php">Facilities</a></li>
                <li><a href="about us.php">About Us</a></li>
                <li><a href="contact us.php">Contact Us</a></li>
            </ul>
        </div>
        
            <div id="widercontent">
                <div id="centreColumn">
                    
                    <span><h1>So, who are we?</h1></span>
        
                        <p>A premium 4-star destination nestled in Queensland, Paradise Lagoon Resort is one of the top Queensland resorts for family holidays, group getaways and weekend escapes.
                        Opened in January 2016, the Paradise Lagoon Resort is one of Australia's largest Waterpark resorts. Roughly 173,000 square feet in area, the owner has been working diligently 
                        to make sure each and every customer who stops by is left full refreshed and satisfied.</p> 
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                        tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at. Suspendisse hendrerit egestas
                        euismod. Sed in nulla commodo, efficitur sapien eleifend, tempor ex.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                        tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at. Suspendisse hendrerit egestas
                        euismod. Sed in nulla commodo, efficitur sapien eleifend, tempor ex.</p>
                
                    <img src="img/couple-in-water-3.jpg" alt="Couples"/>
                    
                    
                </div>
                
                <div id="sociallinks">
                    <a href="https://www.facebook.com"> 
                        <img src="img/media_fb.png" alt="FaceBook"/></a>
                    <a href="https://twitter.com">
                        <img src="img/media_twitter.png" alt="Twitter"/></a> 
                </div>
                    <hr>
                <div id="footer">
                            <p>Griffith University</p>
                            <p>(07) 3735 7111 Griffith University</p>
                            <p>Terms & Conditions</p>
                            <p>Privacy Statement </p>
                            <p>F.A.Q.s</p>
                            <p>Support</p>
                            <p>© Copyright 2016 Paradise Lagoon Resort</p>
                </div>
            </div> 
        </div>
    </body>
</html>
