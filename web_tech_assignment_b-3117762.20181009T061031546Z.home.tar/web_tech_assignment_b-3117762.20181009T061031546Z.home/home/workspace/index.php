
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="keywords" content="Paradise Lagoon, Resort, Paradise, WaterSports">
        <meta name="description" content="Paradise Lagoon Resort is located in the heart of South East Queensland!">
        <title>Home</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>

    <body>
        <div id="global">
        <div id="banner"></div>
        <div id="navbar">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="facilities.php">Facilities</a></li>
                <li><a href="about us.php">About Us</a></li>
                <li><a href="contact us.php">Contact Us</a></li>
            </ul>
        </div>
        
        <div id="content">
                <div id="leftColumn">
                    
                    <h1>Welcome to Paradise</h1>
        
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                        tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at. Suspendisse hendrerit egestas
                        euismod. Sed in nulla commodo, efficitur sapien eleifend, tempor ex. </p>
                        <p>Rooms include 3 bedroom poolside apartments, 2 bedroom poolside or garden villas and king-size bed or twin bed standard rooms with ocean or garden views. All rooms are luxurious throughout, including
                        gourmet kitchens with granite countertops, custom cabinets, and Subzero refrigerators.  Completely furnished with décor to compliment the plantation style, the poolside villas offer hardwood and tile 
                        flooring, natural stone bathrooms, and expansive lanais that extend the living area outdoors.</p>
                
                    <img src="img/Happy-couple.jpg" width="545" height="370" alt="Couples"/>
                
                        <p>With the most all-inclusive packages available, Paradise Lagoon Resort allows you to have a relaxing and laid-back holiday or enjoy a huge range of sports and activities that will have you coming 
                        back for more!</p>
        
                    <h1>Night Life</h1>
        
                        <p>Not tired yet? Don’t worry, you don’t have to stop just because the sun’s gone down. Paradise Lagoon Resort fun keeps going as long as you do with a range of entertainment to take you 
                        through the night.</p>
                
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                        tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam,</p>
                        <p>Rockstarz Is the hottest music venue and nightclub!</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in 
                        tincidunt erat nunc vitae leo. Ut at pharetra ipsum. Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam,</p>
                
                    <img src="img/nightlife-7.jpg" width="545" height="389" alt="NightLife"/>
                
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus lobortis neque, vel faucibus sapien molestie non. 
                        Morbi elementum, odio ac tincidunt aliquet, urna leo gravida diam, in tincidunt erat nunc vitae leo. Ut at pharetra ipsum. 
                        Quisque ut nibh suscipit, pellentesque lectus non, tincidunt est. Sed euismod ex quam, vel bibendum nisi pharetra at. 
                        Suspendisse hendrerit egestaseuismod. Sed in nulla commodo, efficitur sapien eleifend, tempor ex. Sed sodales cursus turpis 
                        imperdiet cursus. Nunc nec purus venenatis nulla eleifend porta at venenatis libero. Duis nec elementum  neque. Morbi blandit,
                        odio vitae hendrerit convallis, odio nunc ornare risus, a tempus nisi turpis bibendum tellus. Duis convallis, mauris ac fringilla finibus, 
                        sapien erat gravida diam, ut pulvinar neque est ut risus. Curabitur aliquam libero at augue pulvinar, ut convallis enim eleifend.</p>
                
                    <div class="sociallinks">
                        <a href="https://www.facebook.com"> 
                            <img src="img/media_fb.png" alt="FaceBook"/></a>
                        <a href="https://twitter.com">
                            <img src="img/media_twitter.png" alt="Twitter"/></a> 
                    </div>
                </div>
                
                <div id="rightColumn">
         
                    <h1>Happy Hour Specials</h1>
                    
                        <p>Never miss our happy hour specials every night between 7:00pm and 8:00pm.</p>
                        <p>Half price drinks and heavily discounted snacks most nights.</p>
                        
                    <img src="img/nightlife-6.jpg" width="545" height="327" alt="Happy Hour"/>
        
                    <h1>In-House Entertainment.</h1>
                    
                        <p>Aren't feeling up to heading out for the night? Relax with some in-house entertainment:</p>
        
                        <ul>
                            <li>1 Nintendo WII</li>
                            <li>Table Tennis</li>
                            <li>2 Billiard Tables</li>
                            <li>1 Air hockey Table </li>
                            <li>2 Chess Table</li>
                            <li>Darts Corner</li>
                            <li>Dance/Karaoke TV Station</li>
                            <li>Books and Magazines</li>
                        </ul>
        
                    <h1>Special OfferBed & Breakfast</h1>
                    
                        <p>It doesn't matter if you're planning a special occasion or simply need to unwind, make the most of your weekend and book a 
                        Bed & Breakfast package for the same price as a standard room booking.</p>
                        <p>Book By 14 June 2016!</p>
                        <p>Stay Starting 01 July! 2016!</p>
                        <p>A variety of dishes such as classic innovative dishes including roasted Cornish Game Hen with saffron rice and a variety 
                        of wood-fired pizzas and freshly baked bread.</p>
                        
                    <img src="img/breakfast.jpg" width="545" height="652" alt="Breakfast"/>
                    
                </div>
                    <hr>
                </div>
                
                <div id="footer">
                        <p>Griffith University</p>
                        <p>(07) 3735 7111 Griffith University</p>
                        <p>Terms & Conditions</p>
                        <p>Privacy Statement </p>
                        <p>F.A.Q.s</p>
                        <p>Support</p>
                        <p>© Copyright 2016 Paradise Lagoon Resort</p>
                </div>
            </div> 
        </div>
    </body>
</html>
